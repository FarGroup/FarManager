To compile the MoonScript library into one file, run build.bat.

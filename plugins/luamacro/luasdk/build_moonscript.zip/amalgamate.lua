-- Started: 2014-04-22
local lfs = require "lfs"

local function is_abs_path(path)
  return (path:match("^[a-zA-Z]:") or path:match("^[\\/]")) and true
end

local function join(...)
  local t, startindex = {...}, 1
  for i,p in ipairs(t) do
    if is_abs_path(p) then startindex=i end
  end
  local s = table.concat(t, "\\", startindex):gsub("[\\/]+","\\")
  return s
end

local function walk(root, callback, cbdata)
  local dirs, files = {}, {}
  for f in lfs.dir(root) do
    if f~="." and f~=".." then
      local attr = lfs.attributes(join(root,f),"mode")
      if attr=="directory" then dirs[#dirs+1]=f
      elseif attr=="file" then files[#files+1]=f
      end
    end
  end
  if callback(cbdata,root,dirs,files) then return true end
  for _,d in ipairs(dirs) do
    if walk(join(root,d),callback,cbdata) then return true end
  end
end

--------------------------------------------------------------------------------
-- -o<filename>    output file (mandatory parameter)
-- -r<dirname>     root directory for the following -d and -f parameters
-- -d<dirname>     directory name relative to the last given root directory
-- -f<filename>    file name relative to the last given root directory
-- -p<text>        a line of text to be appended to output file
--
-- No space is allowed between a prefix and the following parameter.
--------------------------------------------------------------------------------
local function ReadParams(cmdline)
  local params = {}
  local last
  for idx, item in ipairs(cmdline) do
    local prefix, body = item:match("(%-.)(.+)")
    if prefix=="-o" then
      params.outfile = body
    elseif prefix=="-r" then
      last = { root=body, dirs={}, files={} }
      table.insert(params, last)
    elseif prefix=="-f" and last then
      table.insert(last.files, body)
    elseif prefix=="-d" and last then
      table.insert(last.dirs, body)
    elseif prefix=="-p" then
      params.postscript = body
    else
      error("invalid or misplaced parameter #"..idx)
    end
  end
  assert(params.outfile, "no output file specified")
  return params
end

local function process_files(data, root, _, files)
  for _,fname in ipairs(files) do
    if fname:lower():match(data.fpattern) then
      local fullname = join(root,fname)
      local arrname = string.sub(fullname,data.start,-5):gsub("[\\/]", ".")
      local fp = assert(io.open(fullname))
      data.modules[arrname] = fp:read("*all")
      fp:close()
    end
  end
end

local params = ReadParams {...}
local data = { modules={}, fpattern="%.lua$" }
for _,v in ipairs(params) do
  data.start = v.root:find("[\\/]$") and #v.root+1 or #v.root+2
  for _,f in ipairs(v.files) do process_files(data, v.root, nil, {f}) end
  for _,d in ipairs(v.dirs) do walk(join(v.root, d), process_files, data) end
end

local fp = io.open(params.outfile, "w")
for modname,modtext in pairs(data.modules) do
  local eol = string.sub(modtext,-1)=="\n" and "" or "\n"
  fp:write("package.preload[\"", modname, "\"] = function()\n", modtext, eol, "end\n\n")
end
if params.postscript then
  fp:write(params.postscript, "\n")
end
fp:close()
